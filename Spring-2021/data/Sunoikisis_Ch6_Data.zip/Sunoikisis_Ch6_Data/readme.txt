Originally published: 2021-02-03
This version: 1

*******************

GENERAL INFORMATION

*******************

1. TITLE

Example dataset accompanying Session 6, "Geographic Information Systems," Sunoikisis Digital Cultural Heritage, Spring 2021

2. AUTHOR INFORMATION

Dr. Rebecca M. Seifried
University of Massachusetts Amherst
Amherst, MA, USA
rseifried@umass.edu
rmseifried@gmail.com (permanent)

3. DESCRIPTION

GIS data for experimenting with viewshed analysis from sites of cultural heritage in the southern Peloponnese. The exercise and a link to the video tutorial can be found at: https://github.com/SunoikisisDC/SunoikisisDC-2020-2021/wiki/CH6-GIS

4. LICENSES

This data package is made available under the Creative Commons Attribution 4.0 International License: https://creativecommons.org/licenses/by/4.0/legalcode.


**********************

DATA AND FILE OVERVIEW

**********************

1. FILE LIST

A. Fortress_Achillio.shp, Fortress_Kelefa.shp, Fortress_Passava.shp

Locations of 3 early modern fortresses in the southern Mani peninsula, Greece. The shapefiles were created based on the author's knowledge of the sites' locations and digitized using Bing satellite imagery. For more information about the sites and a bibliography, see the entries for Achillio Fortress (T430), Kelepha Fortress (T343), and Passava Fortress (T224) in Appendix A in Seifried (2016). Projected Coordinate System: WGS84 UTM Zone 34N.

B. SRTM1.tif

SRTM 1 Arc-Second Global data retrieved from the online USGS Earth Explorer, courtesy the USGS/Earth Resources Observation and Science (EROS) Center. The tile SRTM1N36E022V3 was projected from WGS84 (decimal degree) using the "Warp (Reproject)" tool in QGIS 3.4. Projected Coordinate System: WGS84 UTM Zone 34N.


**********

REFERENCES

**********

Seifried, Rebecca M. (2016). Community Organization and Imperial Expansion in a Rural Landscape: The Mani Peninsula (AD 1000-1821). PhD dissertation. Department of Anthropology, University of Illinois at Chicago. https://hdl.handle.net/10027/21274

